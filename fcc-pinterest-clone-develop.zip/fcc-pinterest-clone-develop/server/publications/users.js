Meteor.publish('users', function() {
   return Meteor.users.find({}, {
       fields: {
           'profile.name': 1
       }
   });
});
