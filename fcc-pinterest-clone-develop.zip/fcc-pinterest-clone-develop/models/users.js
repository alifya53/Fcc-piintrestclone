Meteor.users.initEasySearch('username');
Meteor.users.attachSchema(Schema.User);

