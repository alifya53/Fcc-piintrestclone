Favorites = new Meteor.Collection('favorites');
Favorites.attachSchema(Schema.Favorites);
